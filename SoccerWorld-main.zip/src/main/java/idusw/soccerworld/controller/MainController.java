package idusw.soccerworld.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {
}
